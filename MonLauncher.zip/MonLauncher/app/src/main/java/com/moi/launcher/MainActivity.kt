package com.moi.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF0F2233.toInt())
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    // On revient sur l'accueil : on rafraîchit la liste (nouvelles apps, récents)
    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.refresh && refresh()", null)
    }

    // L'accueil ne se ferme pas avec Retour
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val seen = HashSet<String>()
            val out = JSONArray()
            for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (r in pm.queryIntentActivities(intent, 0)) {
                    val a = r.activityInfo
                    if (a.packageName == packageName || !seen.add(a.packageName)) continue
                    out.put(
                        JSONObject()
                            .put("label", r.loadLabel(pm).toString())
                            .put("pkg", a.packageName)
                            .put("cls", a.name)
                            .put("icon", iconToDataUri(r.loadIcon(pm)))
                    )
                }
            }
            return out.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String, cls: String) {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Intent.ACTION_MAIN)
                            .setComponent(ComponentName(pkg, cls))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) { /* app supprimée ou bloquée */ }
            }
        }
    }

    private fun iconToDataUri(d: Drawable): String {
        val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 128, 128)
        d.draw(Canvas(bmp))
        val s = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, s)
        bmp.recycle()
        return "data:image/png;base64," + Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
    }
}
